

const Course = require('../models/course');
const User = require('../models/user.model');

module.exports.bookCourse = async (req, res) => {
    try {
        const { userId } = req.body;
        const courseId = req.params.id;

        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({ message: 'Course not found' });
        }

        // Attempt to book the course for the user
        await course.bookCourse(userId);

        // Respond with success message
        res.json({ message: 'Course booked successfully' });
    } catch (err) {
        console.error(err);
        res.status(400).json({ message: err.message });
    }
};
  
  
// Create 
module.exports.createCourse= (req,res)=>{
    Course.create(req.body)
    .then((course)=> res.json(course))
    .catch((err)=> res.json(err))
};

// GET ALL
module.exports.getAllCourse =(req,res)=>{
    Course.find()
    .then((courses)=>res.json(courses))
    .catch((err)=> res.json(err))
};
// GET ONE BY ID

module.exports.getOneCourseById =(req,res)=>{
    Course.findById({_id: req.params.id})
    .then((course)=>res.json(course))
    .catch((err)=> res.json(err))
};

// DELETE
module.exports.deleteOneCourse =async (req, res) => {
    Course.findByIdAndDelete({ _id: req.params.id })
    .then((course)=>res.json(course))
    .catch((err)=>res.json(err))
};

// UPDATE by iD

module.exports.updateCourseById =(req,res)=>{
    Course.findByIdAndUpdate({_id:req.params.id}, req.body, {
        new: true,
        runValidators: true
    })
    .then((updateCourse)=>res.json(updateCourse))
    .catch((err)=> res.status(400).json(err));
};
module.exports.getAvailableCourses = (req, res) => {
    Course.findAvailableCourses()
      .then(courses => res.json(courses))
      .catch(err => res.status(400).json(err));
  };
  
  module.exports.getBookedCourses = async (req, res) => {
    try {
      const userId = req.params.userId;
      const user = await User.findById(userId).populate('bookedCourses');
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json({ bookedCourses: user.bookedCourses });
    } catch (err) {
      console.error(err);
      res.status(400).json({ message: err.message });
    }
  };