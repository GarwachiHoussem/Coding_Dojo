import Home from "./components/Home";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AuthForm from "./components/AuthForm";
import CourseForm from "./components/CourseForm";
import MessageForm from "./components/MessageForm";

import AboutUs from "./components/AboutUs";
import SolarEnergyPage from "./components/AboutUs";
import { AuthProvider } from "./components/AuthContext";
import SolarPanelInstallation from "./components/SolarPanelInstallation";
import Courses from "./components/Dashboard/Courses";
import Dashboard from "./components/Dashboard";
import AdminDashboard from "./components/Dashboard/AdminDashboard";
import AuthFormAdmin from "./components/AuthFormAdmin";

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path={"*"} element={<Navigate to={"/Home"} />} />

        <Route path="/Home" element={<Home />} />

        <Route
          path="/LoginReg"
          element={
            <>
              <Navbar />
              <AuthForm />
              <Footer />
            </>
          }
        />
        <Route
          path="/register Admin"
          element={
            <>
              <Navbar />
              <AuthFormAdmin />
              <Footer />
            </>
          }
        />
        <Route
          path="/services/solar-panel-installation"
          element={
            <>
              <Navbar />
              <SolarPanelInstallation />
              <Footer />
            </>
          }
        />
        <Route
          path="/services/courses"
          element={
            <>
              <Navbar />
              <Courses />
              <Footer />
            </>
          }
        />

        <Route
          path="/Dashboard"
          element={
            <>
              <AdminDashboard />
            </>
          }
        />

        <Route
          path="/Contact us"
          element={
            <>
              <Navbar />
              <MessageForm />
              <Footer />
            </>
          }
        />

        <Route
          path="/About us"
          element={
            <>
              <Navbar />
              <AboutUs />
              <Footer />
            </>
          }
        />
      </Routes>
    </AuthProvider>
  );
}

export default App;
