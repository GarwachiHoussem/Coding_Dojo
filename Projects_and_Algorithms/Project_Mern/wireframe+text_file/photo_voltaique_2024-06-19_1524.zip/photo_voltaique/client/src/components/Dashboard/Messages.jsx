import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Messages = () => {
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/messages')
            .then((res) => {
                // Assuming the API returns an array of message objects with a 'recipient' attribute
                const filteredMessages = res.data.filter(message => message.recipient === 'student');
                setMessages(filteredMessages);
            })
            .catch((error) => {
                console.error('Error fetching messages:', error);
            });
    }, []);

    return (
        <div className="container mx-auto px-4 py-8">
            <h2 className="text-2xl font-bold mb-4">Student Messages</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {messages.map((message) => (
                    <div key={message.id} className="bg-white shadow-md rounded-lg overflow-hidden">
                        <div className="p-4">
                            <p className="text-lg font-bold">{message.subject}</p>
                            <p className="text-gray-500">{message.content}</p>
                            {/* Other message details */}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Messages;
