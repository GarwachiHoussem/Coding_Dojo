import React, { useEffect, useState } from 'react';
import axios from 'axios';

const CoursesTable = ({courses, setCourses}) => {
    const [editCourse, setEditCourse] = useState(null);
    const [showModal, setShowModal] = useState(false);
    

    useEffect(() => {
        axios.get('http://localhost:8000/api/courses')
            .then((res) => {
                setCourses(res.data);
            })
            .catch((err) => console.error(err));
    }, []);

    const handleRemove = (id) => {
        axios.delete(`http://localhost:8000/api/courses/${id}`)
            .then((res) => {
                setCourses(courses.filter(course => course._id !== id));
            })
            .catch((err) => console.error(err));
    };

    const handleEdit = (course) => {
        setEditCourse(course);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setEditCourse(null);
        setShowModal(false);
    };

    const handleSave = () => {
        console.log("edit courses ======>",editCourse)
        axios.patch(`http://localhost:8000/api/courses/${editCourse._id}`, editCourse)
            .then((res) => {
                setCourses(courses.map(course => (course._id === res.data._id ? res.data : course)));
                handleCloseModal();
            })
            .catch((err) => console.error(err));
    };

    const handlePlanChange = (index, field, value) => {
        const updatedPlan = [...editCourse.plan];
        updatedPlan[index][field] = value;
        setEditCourse({ ...editCourse, plan: updatedPlan });
    };

    const addPlanEntry = () => {
        setEditCourse({ ...editCourse, plan: [...editCourse.plan, { date: '', time: '' }] });
    };

    const removePlanEntry = (index) => {
        const updatedPlan = editCourse.plan.filter((_, i) => i !== index);
        setEditCourse({ ...editCourse, plan: updatedPlan });
    };

    return (
        <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
                <thead>
                    <tr>
                        <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Title</th>
                        <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Instructor</th>
                    </tr>
                </thead>
                <tbody>
                    {courses.map((course) => (
                        <tr key={course._id}>
                            <td className="py-2 px-4 border-b border-gray-300">{course.title}</td>
                            <td className="py-2 px-4 border-b border-gray-300">{course.instructor}</td>
                           
                            <td className="py-2 px-4 border-b border-gray-300">
                                <button
                                    onClick={() => handleEdit(course)}
                                    className="bg-blue-500 text-white px-4 py-2 rounded-md mr-2"
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleRemove(course._id)}
                                    className="bg-red-500 text-white px-4 py-2 rounded-md"
                                >
                                    Remove
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {showModal && (
                <div className="fixed z-10 inset-0 overflow-y-auto">
                    <div className="flex items-center justify-center min-h-screen">
                        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={handleCloseModal}></div>
                        <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all sm:max-w-lg sm:w-full">
                            <div className="px-4 py-5 sm:p-6">
                                <h3 className="text-lg leading-6 font-medium text-gray-900">Edit Course</h3>
                                <div className="mt-2">
                                    <form className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Title</label>
                                            <input
                                                type="text"
                                                value={editCourse.title}
                                                onChange={(e) => setEditCourse({ ...editCourse, title: e.target.value })}
                                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Instructor</label>
                                            <input
                                                type="text"
                                                value={editCourse.instructor}
                                                onChange={(e) => setEditCourse({ ...editCourse, instructor: e.target.value })}
                                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Instructor</label>
                                            <input
                                                type="number"
                                                value={editCourse.places}
                                                onChange={(e) => setEditCourse({ ...editCourse, places: e.target.value })}
                                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Details</label>
                                            <textarea
                                                value={editCourse.details}
                                                onChange={(e) => setEditCourse({ ...editCourse, details: e.target.value })}
                                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Plan</label>
                                            {editCourse.plan.map((entry, index) => (
                                                <div key={index} className="flex space-x-2">
                                                    <input
                                                        type="date"
                                                        value={entry.date}
                                                        onChange={(e) => handlePlanChange(index, 'date', e.target.value)}
                                                        className="mt-1 block w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                                    />
                                                    <input
                                                        type="time"
                                                        value={entry.time}
                                                        onChange={(e) => handlePlanChange(index, 'time', e.target.value)}
                                                        className="mt-1 block w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                                    />
                                                    <button
                                                        type="button"
                                                        onClick={() => removePlanEntry(index)}
                                                        className="bg-red-500 text-white px-2 py-1 rounded-md"
                                                    >
                                                        Remove
                                                    </button>
                                                </div>
                                            ))}
                                            <button
                                                type="button"
                                                onClick={addPlanEntry}
                                                className="bg-green-500 text-white px-4 py-2 rounded-md mt-2"
                                            >
                                                Add Plan Entry
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div className="px-4 py-3 bg-gray-50 sm:px-6 sm:flex sm:flex-row-reverse">
                                <button
                                    onClick={handleSave}
                                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-500 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                                >
                                    Save
                                </button>
                                <button
                                    onClick={handleCloseModal}
                                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CoursesTable;
