import React from 'react';
import { Routes, Route, Link, Outlet } from 'react-router-dom';
import Home from './Home';
import Users from './Dashboard/Users';
import Courses from './Dashboard/Courses';
import Messages from './Dashboard/Messages';
import { useAuth } from './AuthContext';

const Dashboard = () => {
    const { role: userRole } = useAuth();

    return (
        <div className="flex h-screen">
            {/* Sidebar */}
            <div className="bg-gray-800 text-gray-100 w-64 flex flex-col">
                <div className="p-4 bg-gray-900">
                    <h2 className="text-2xl font-bold">Dashboard</h2>
                    <p className="mt-1 text-sm">{userRole === 'admin' ? 'Admin Dashboard' : 'Student Dashboard'}</p>
                </div>
                <nav className="flex-1 overflow-y-auto">
                    <ul className="p-2">
                        <li>
                            <Link to="/" className="block py-2 px-4 hover:bg-gray-700">
                                Home
                            </Link>
                        </li>
                        {userRole === 'admin' && (
                            <>
                                <li>
                                    <Link to="/users" className="block py-2 px-4 hover:bg-gray-700">
                                        Users
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/courses" className="block py-2 px-4 hover:bg-gray-700">
                                        Courses
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/messages" className="block py-2 px-4 hover:bg-gray-700">
                                        Messages
                                    </Link>
                                </li>
                            </>
                        )}
                    </ul>
                </nav>
            </div>
            {/* Main Content */}
            <div className="flex-1 p-8">
                <Routes>
                    <Route path="/users" element={<Users />} />
                    <Route path="/courses" element={<Courses />} />
                    {userRole === 'admin' && (
                        <Route path="/messages" element={<Messages />} />
                    )}
                </Routes>
            </div>
        </div>
    );
};

export default Dashboard;
