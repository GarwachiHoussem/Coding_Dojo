import React, { useEffect } from 'react';
import { IoHome } from 'react-icons/io5';
import { FaMicroblog } from 'react-icons/fa';
import { TiMessages } from 'react-icons/ti';
import { RiCustomerService2Fill } from 'react-icons/ri';
import { VscGitPullRequestGoToChanges } from "react-icons/vsc";
import { SiCoursera } from "react-icons/si";


import { FaUsers } from "react-icons/fa6";

import { Link } from 'react-router-dom';
import { CiLogout } from 'react-icons/ci';
import {useAuth} from "../AuthContext"
const Sidebar = ({ setcontent }) => {
  const { role,username,email } = useAuth(); // Access role using useAuth hook
  console.log("this the role =======>",role)
  useEffect(() => {
    if (role === "student") {
      setcontent(4);
    }
  }, [role]);
  return (
    <div className="flex flex-col h-full bg-gray-800 fixed left-0 top-0 w-1/5 ">
      <div className="space-y-3 mt-10">
        
        <div>
          <h2 className="font-medium text-xs md:text-sm text-center text-teal-500">
            {username}
          </h2>
          <h2 className="font-medium text-xs md:text-sm text-center text-teal-500">
            {email}
          </h2>
          <p className="text-xs text-gray-500 text-center">{role === 'admin' ? 'Administrator' : 'Student'}</p>
        </div>
      </div>
      <nav className="flex-1 flex flex-col justify-center space-y-4">
        <Link to="/Home">
          <div className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer">
            <IoHome className="mr-4" />
            <span>Home</span>
          </div>
        </Link>
        {role === 'student' && (
          <div
            onClick={() => {
              setcontent(4); // Assuming content index for "Historique de service"
              console.log('hatha 4');
            }}
            className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer"
          >
            <FaMicroblog className="mr-4" />
            <span>My Courses</span>
          </div>
        )}
       
        
       
        {role === 'admin' && (
          <>
            <div
              onClick={() => {
                setcontent(0);
                console.log('hatha 0');
              }}
              className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer"
            >
              <FaUsers className="mr-4"/>

              <span>Users</span>
            </div>
            <div
              onClick={() => {
                setcontent(1);
                console.log('hatha 1');
              }}
              className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer"
            >
              <TiMessages className="mr-4" />
              <span>Messages</span>
            </div>
            <div
              onClick={() => {
                setcontent(2);
                console.log('hatha 2');
              }}
              className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer"
            >
              <SiCoursera className="mr-4" />

              <span>Courses</span>
            </div>
            <div
              onClick={() => {
                setcontent(3);
                console.log('hatha 3');
              }}
              className="flex items-center justify-start text-gray-300 hover:bg-gray-700 py-2 px-6 cursor-pointer"
            >
              <VscGitPullRequestGoToChanges  className="mr-4"/>

              <span>Panel Installation Requests</span>
            </div>
          </>
        )}
      </nav>
      {/* Logout */}
      <div className="flex justify-center items-center mt-auto hover:bg-gray-700 py-4">
        <button
          onClick={() => {
            // Handle logout logic here
            console.log('Logout clicked');
          }}
          className="flex items-center text-gray-300 py-2 px-6 cursor-pointer"
        >
          <CiLogout className="mr-4" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;