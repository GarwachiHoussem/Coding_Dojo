import React, { useEffect, useState } from 'react';
import axios from 'axios';

const CourseCard = ({ course, userId, role }) => {
  const { title, instructor, details, plan, availablePlaces } = course;
  const [loading, setLoading] = useState(false);

  const bookCourse = async () => {
    setLoading(true);
    try {
      console.log('User ID:', userId);
      const response = await axios.post(`http://localhost:8000/api/courses/${course._id}/book`, { userId });
      console.log('Booking successful:', response.data);
      alert('Course booked successfully.');
      // Update available places in the course object
      course.availablePlaces -= 1;
    } catch (error) {
      console.error('Booking failed:', error);
      alert(error.response.data.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden h-full">
      <div className="px-6 py-4 h-full flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">{title}</h2>
          <p className="text-gray-600">Instructor: {instructor}</p>
          <p className="text-gray-600">Available Places: {availablePlaces}</p>

          <p className="text-gray-700 mt-4">{details}</p>
          <div className="mt-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Schedule</h3>
            <ul className="space-y-2">
              {plan.map((item, index) => (
                <li key={index} className="flex items-center">
                  <svg
                    className="w-4 h-4 mr-2"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14M12 5l7 7-7 7"></path>
                  </svg>
                  <span className="font-medium">
                    {item.date} at {item.time}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {role === 'student' && (
          <div className="mt-4">
            <button
              onClick={bookCourse}
              disabled={loading}
              className={`bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md focus:outline-none ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? 'Booking...' : 'Book Now'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseCard;
