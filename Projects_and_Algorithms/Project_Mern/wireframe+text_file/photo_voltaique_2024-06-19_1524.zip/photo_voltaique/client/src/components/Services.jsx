// src/pages/Services.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import solarPanelImage from '../images/img3.jpeg'; // Add the correct path to your image
import coursesImage from '../images/C.png'; // Add the correct path to your image

const Services = () => {
    const navigate = useNavigate();

    return (
        <div className="max-w-7xl mx-auto p-8 bg-white rounded-lg">
            <h2 className="text-4xl font-bold mb-12 text-center text-gray-800">Our Services</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="relative group p-6 rounded-lg overflow-hidden transition-shadow duration-300 hover:shadow-xl">
                    <img src={solarPanelImage} alt="Solar Panel Installation" className="w-full h-64 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105" />
                    <div className="p-6 bg-gray-100">
                        <h3 className="text-2xl font-semibold mb-4 text-gray-800">Solar Panel Installation</h3>
                        <p className="mb-6 text-gray-600">We offer professional solar panel installation services to help you harness the power of the sun. Our experienced team ensures that your solar panels are installed efficiently and effectively.</p>
                        <button 
                            onClick={() => navigate('/services/solar-panel-installation')}
                            className="w-full bg-indigo-600 text-white py-3 px-6 rounded-md shadow-md hover:bg-indigo-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            Learn More
                        </button>
                    </div>
                </div>
                <div className="relative group p-6 rounded-lg overflow-hidden transition-shadow duration-300 hover:shadow-xl">
                    <img src={coursesImage} alt="Courses on Solar Stations" className="w-full h-64 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105" />
                    <div className="p-6 bg-gray-100">
                        <h3 className="text-2xl font-semibold mb-4 text-gray-800">Courses on Solar Stations</h3>
                        <p className="mb-6 text-gray-600">We offer comprehensive courses on solar stations, designed to provide you with the knowledge and skills needed to excel in the solar energy industry. Book a course with us today!</p>
                        <button 
                            onClick={() => navigate('/services/courses')}
                            className="w-full bg-indigo-600 text-white py-3 px-6 rounded-md shadow-md hover:bg-indigo-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            Book a Course
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Services;
