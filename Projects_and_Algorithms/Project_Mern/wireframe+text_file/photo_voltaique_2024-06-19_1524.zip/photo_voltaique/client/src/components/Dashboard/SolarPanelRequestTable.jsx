import React, { useState, useEffect } from 'react';
import axios from 'axios';

const SolarPanelRequestTable = () => {
    const [requests, setRequests] = useState([]);
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        axios.get('http://localhost:8000/api/solar-panel/installation')
            .then((res) => {
                setRequests(res.data);
            })
            .catch((error) => {
                console.error('Error fetching solar panel requests:', error);
            });
    }, []);

    const handleDelete = (id) => {
        axios.delete(`http://localhost:8000/api/solar-panel/installation/${id}`)
            .then(() => {
                setRequests(requests.filter(request => request._id !== id));
            })
            .catch((error) => {
                console.error('Error deleting solar panel request:', error);
            });
    };

    const handleView = (request) => {
        setSelectedRequest(request);
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setSelectedRequest(null);
    };

    return (
        <div className="container mx-auto px-4 py-8">
            <h2 className="text-2xl font-bold mb-4">Solar Panel Installation Requests</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead>
                        <tr>
                            <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Name</th>
                            <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Email</th>
                            <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Phone</th>
                            <th className="py-2 px-4 border-b-2 border-gray-300 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {requests.map((request) => (
                            <tr key={request._id}>
                                <td className="py-2 px-4 border-b border-gray-300">{request.name}</td>
                                <td className="py-2 px-4 border-b border-gray-300">{request.email}</td>
                                <td className="py-2 px-4 border-b border-gray-300">{request.phone}</td>
                                <td className="py-2 px-4 border-b border-gray-300">
                                    <button
                                        onClick={() => handleView(request)}
                                        className="bg-blue-500 text-white px-4 py-2 rounded-md mr-2"
                                    >
                                        View
                                    </button>
                                    <button
                                        onClick={() => handleDelete(request._id)}
                                        className="bg-red-500 text-white px-4 py-2 rounded-md"
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {showModal && selectedRequest && (
                <div className="fixed z-10 inset-0 overflow-y-auto">
                    <div className="flex items-center justify-center min-h-screen">
                        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={closeModal}></div>
                        <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all sm:max-w-lg sm:w-full">
                            <div className="px-4 py-5 sm:p-6">
                                <h3 className="text-lg leading-6 font-medium text-gray-900">Request Details</h3>
                                <div className="mt-2">
                                    <p className="text-sm text-gray-500"><strong>Name:</strong> {selectedRequest.name}</p>
                                    <p className="text-sm text-gray-500"><strong>Email:</strong> {selectedRequest.email}</p>
                                    <p className="text-sm text-gray-500"><strong>Phone:</strong> {selectedRequest.phone}</p>
                                    <p className="text-sm text-gray-500"><strong>Power Needed (kW):</strong> {selectedRequest.powerNeeded}</p>
                                    <p className="text-sm text-gray-500"><strong>Available Space (sq ft):</strong> {selectedRequest.availableSpace}</p>
                                    <p className="text-sm text-gray-500"><strong>Description:</strong> {selectedRequest.description}</p>
                                </div>
                            </div>
                            <div className="px-4 py-3 bg-gray-50 sm:px-6 sm:flex sm:flex-row-reverse">
                                <button
                                    onClick={closeModal}
                                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-500 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default SolarPanelRequestTable;
