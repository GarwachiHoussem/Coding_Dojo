import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { HiOutlineViewGrid } from 'react-icons/hi';

const Navbar = () => {
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const { token, logout, role } = useAuth();
    const dropdownRef = useRef(null);

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    const handleLogoutClick = () => {
        logout();
        navigate('/'); // Redirect to home page after logout
    };

    const handleDropdownToggle = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setIsDropdownOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <nav className="bg-sky-500 p-1">
            <div className="container mx-auto flex justify-between items-center">
                <img src="../Logo.png" alt="Logo" className="w-20 ml-8" />
                <div className="flex items-center">
                    <div className="hidden md:flex space-x-4">
                        <Link to="/home" className="text-white px-3 py-2 rounded-md text-sm font-medium">Home</Link>
                        <div className="relative" ref={dropdownRef}>
                            <button 
                                onClick={handleDropdownToggle}
                                className="text-white px-3 py-2 rounded-md text-sm font-medium focus:outline-none"
                            >
                                Services
                            </button>
                            {isDropdownOpen && (
                                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                                    <Link to="/services/solar-panel-installation" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Solar Panel Installation</Link>
                                    <Link to="/services/courses" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Courses on Solar Stations</Link>
                                </div>
                            )}
                        </div>
                        <Link to="/About us" className="text-white px-3 py-2 rounded-md text-sm font-medium">About Us</Link>
                        <Link to="/Contact us" className="text-white px-3 py-2 rounded-md text-sm font-medium">Contact Us</Link>
                    </div>
                </div>
                <div className="hidden md:flex space-x-2 mr-8">
                    {token ? 
                    <>
                        <button className="primary-btn" onClick={handleLogoutClick}>Logout</button>
                        <Link to="/dashboard" className="flex items-center gap-2 text-white px-3 py-2 rounded-md text-sm font-medium">
                            <HiOutlineViewGrid className="text-xl" />
                            Dashboard
                        </Link>
                    </>
                    : <Link to="/LoginReg" className="text-white bg-green-500 px-3 py-2 rounded-md text-sm font-medium">Sign Up</Link>}
                </div>
                <div className="md:hidden">
                    <button onClick={toggleMenu} className="text-white focus:outline-none">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}></path>
                        </svg>
                    </button>
                </div>
            </div>
            {isOpen && (
                <div className="md:hidden">
                    <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                        <Link to="/home" className="text-white block px-3 py-2 rounded-md text-base font-medium">Home</Link>
                        <div className="relative" ref={dropdownRef}>
                            <button 
                                onClick={handleDropdownToggle}
                                className="text-white block px-3 py-2 rounded-md text-base font-medium focus:outline-none"
                            >
                                Services
                            </button>
                            {isDropdownOpen && (
                                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                                    <Link to="/services/solar-panel-installation" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Solar Panel Installation</Link>
                                    <Link to="/services/courses" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Courses on Solar Stations</Link>
                                </div>
                            )}
                        </div>
                        <Link to="/About us" className="text-white block px-3 py-2 rounded-md text-base font-medium">About Us</Link>
                        <Link to="/Contact us" className="text-white block px-3 py-2 rounded-md text-base font-medium">Contact Us</Link>
                        {token ? 
                        <>
                            <button className="text-white bg-blue-500 block w-full px-3 py-2 rounded-md text-base font-medium" onClick={handleLogoutClick}>Logout</button>
                            <Link to="/dashboard" className="text-white block w-full px-3 py-2 rounded-md text-base font-medium">Dashboard</Link>
                        </>
                        : <Link to="/LoginReg" className="text-white bg-green-500 block w-full px-3 py-2 rounded-md text-base font-medium">Sign Up</Link>}
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navbar;
