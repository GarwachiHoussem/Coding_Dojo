import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';
import img1 from '../images/img1.jpg';
import img2 from '../images/img2.jpg';
import img3 from '../images/img3.jpeg';
import img4 from '../images/img4.jpg';
import Footer from './Footer';
import Services from './Services';


function Home() {
    const images = [img1, img2, img3, img4];
    return (
        <div><Navbar />
            <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-1/2">
                    <div className="p-8 flex-col items-center justify-center">
                        <h1 className="text-3xl font-bold mb-4 text-yellow-600">Welcome to Our Website</h1>
                        <br />

                        <p>Since our creation in 2023, B2H SOL is committed to being your trusted partner in the continuous development of your business. We offer specialized services in continuing education, consulting
                            At B2H SOL, we understand that the success of a company is based on two essential pillars: business. development and improving the skills of employees.
                            Our commitment is to support you in the development of your activities while strengthening the skills of your employees. Explore our services today and find out how B2H SOL can be the catalyst for your business success</p>
                    </div>
                </div>
                <div className="w-full md:w-1/2">
                    <div className="p-8 flex items-center justify-center rounded">
                        <Carousel slides={images} className='rounded' />
                    </div>
                </div>
            </div>
            <Services/>
            <Footer/>
            </div>
    )
}

export default Home
const Carousel = ({ autoSlide = true, autoSlideInterval = 3000, slides }) => {
    const [curr, setCurr] = useState(0);

    const prev = () => setCurr((curr) => (curr === 0 ? slides.length - 1 : curr - 1));
    const next = () => setCurr((curr) => (curr === slides.length - 1 ? 0 : curr + 1));

    useEffect(() => {
        if (autoSlide) {
            const slideInterval = setInterval(next, autoSlideInterval);
            return () => clearInterval(slideInterval);
        }
    }, [autoSlide, autoSlideInterval]);

    return (
        <div className="overflow-hidden relative">
            <div
                className="flex transition-transform ease-out duration-500"
                style={{ transform: `translateX(-${curr * 100}%)` }}
            >
                {slides.map((img, index) => (
                    <img key={index} src={img} alt="" className='rounded-3xl' />
                ))}
            </div>
            <div className="absolute inset-0 flex items-center justify-between p-4">
                <button
                    onClick={prev}
                    className="p-1 rounded-full shadow bg-white bg-opacity-80 text-gray-800 hover:bg-white"
                >
                    &lt;
                </button>
                <button
                    onClick={next}
                    className="p-1 rounded-full shadow bg-white bg-opacity-80 text-gray-800 hover:bg-white"
                >
                    &gt;
                </button>
            </div>

            <div className="absolute bottom-4 right-0 left-0">
                <div className="flex items-center justify-center gap-2">
                    {slides.map((_, i) => (
                        <div
                            key={i}
                            className={`transition-all w-3 h-3 bg-white rounded-full ${curr === i ? 'p-2' : 'bg-opacity-50'
                                }`}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};
