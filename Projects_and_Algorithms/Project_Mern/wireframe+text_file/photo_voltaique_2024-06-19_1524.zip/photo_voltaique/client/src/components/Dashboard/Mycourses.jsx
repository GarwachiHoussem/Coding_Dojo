import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Modal from 'react-modal';
import { useAuth } from '../AuthContext';

function MyCourses() {
  const {userId}=useAuth()
  console.log("************ userId ****",userId)
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);

  useEffect(() => {
    // Fetch booked courses for the user
    const fetchBookedCourses = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/user/${userId}/booked-courses`);
        setCourses(response.data.bookedCourses);
        console.log(courses)
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchBookedCourses();
  }, []);

  const viewCourseDetails = (courseId) => {
    const course = courses.find((course) => course._id === courseId);
    setSelectedCourse(course);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
    setSelectedCourse(null);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="container mx-auto mt-10">
      <h1 className="text-2xl font-bold mb-6">My Courses</h1>
      <table className="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr className="bg-gray-200">
            <th className="border border-gray-300 px-4 py-2">Title</th>
            <th className="border border-gray-300 px-4 py-2">Instructor</th>
            <th className="border border-gray-300 px-4 py-2">Details</th>
            <th className="border border-gray-300 px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course) => (
            <tr key={course._id}>
              <td className="border border-gray-300 px-4 py-2">{course.title}</td>
              <td className="border border-gray-300 px-4 py-2">{course.instructor}</td>
              <td className="border border-gray-300 px-4 py-2">{course.details}</td>
              <td className="border border-gray-300 px-4 py-2">
                <button 
                  className="bg-blue-500 text-white px-4 py-2 rounded"
                  onClick={() => viewCourseDetails(course._id)}
                >
                  View Details
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal 
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        contentLabel="Course Details"
        className="bg-white p-4 rounded-lg shadow-lg max-w-lg mx-auto mt-10"
        overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center"
      >
        {selectedCourse && (
          <div>
            <h2 className="text-xl font-bold mb-4">{selectedCourse.title}</h2>
            <p><strong>Instructor:</strong> {selectedCourse.instructor}</p>
            <p><strong>Details:</strong> {selectedCourse.details}</p>
            <p><strong>Plan:</strong></p>
            <ul>
              {selectedCourse.plan.map((item, index) => (
                <li key={index}>{item.date} at {item.time}</li>
              ))}
            </ul>
            <button 
              className="bg-red-500 text-white px-4 py-2 rounded mt-4"
              onClick={closeModal}
            >
              Close
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}

export default MyCourses;
