import React, { createContext, useContext, useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem("authToken"));
  const [role, setRole] = useState(null);
  const [username,setUsername]=useState(null)
  const [email,setEmail]=useState(null)
  const [userId,setUserId]=useState(null);


  useEffect(() => {
    if (token) {
      try {
        const decoded = jwtDecode(token);
        
        setRole(decoded._doc?.role);
        setUsername(decoded._doc?.username);
        setEmail(decoded._doc?.email);
        setUserId(decoded._doc?._id)

      } catch (error) {
        console.error("Invalid token:", error);
        localStorage.removeItem("authToken");
        setToken(null);
        setRole(null);
      }
    }
  }, [token]);

  const login = (newToken) => {
    console.log(newToken);
    if (typeof newToken === "string") {
      setToken(newToken);
      localStorage.setItem("authToken", newToken);
      try {
        const decoded = jwtDecode(newToken);
        const userRole = decoded._doc?.role;
        setRole(userRole);
        setUsername(decoded._doc?.username);
        setEmail(decoded._doc?.email);
        setUserId(decoded._doc?._id)
        console.log(decoded);
      } catch (error) {
        console.error("Invalid token during login:", error);
        // Handle invalid token error
      }
    } else {
      console.error("Invalid token provided during login");
    }
  };

  const logout = () => {
    setToken(null);
    setRole(null);
    localStorage.removeItem("authToken");
    localStorage.removeItem("userRole");
  };

  return (
    <AuthContext.Provider value={{ token, role,username,email,userId, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
