import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const CourseForm = ({ closeModal ,courses,setCourses}) => {
  const [title, setTitle] = useState('');
  const [instructor, setInstructor] = useState('');
  const [details, setDetails] = useState('');
  const [plan, setPlan] = useState([{ date: '', time: '' }]);
  const [places, setPlaces] = useState(0);  // Add state for places 
  const { id } = useParams();

  useEffect(() => {
    const handleEscapeKey = (event) => {
      if (event.key === 'Escape') {
        closeModal();
      }
    };

    document.addEventListener('keydown', handleEscapeKey);

    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [closeModal]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const courseData = { title, instructor, details, plan,places };

    axios.post('http://localhost:8000/api/courses', courseData)
      .then((res) => {
        console.log("t3adat el creation ======>",res.data);
        setCourses([...courses,courseData])
        closeModal()
      })
      .catch(error => console.error(error));
  };

  const handlePlanChange = (index, event) => {
    const { name, value } = event.target;
    const updatedPlan = [...plan];
    updatedPlan[index][name] = value;
    setPlan(updatedPlan);
  };

  const addPlanField = () => {
    setPlan([...plan, { date: '', time: '' }]);
  };

  const removePlanField = (index) => {
    const updatedPlan = [...plan];
    updatedPlan.splice(index, 1);
    setPlan(updatedPlan);
  };

  return (
    <div className="max-w-3xl mx-auto p-8">
      <h2 className="text-2xl font-bold mb-6">{id ? 'Edit Course' : 'Add Course'}</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Title:</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Instructor:</label>
          <input
            type="text"
            value={instructor}
            onChange={(e) => setInstructor(e.target.value)}
            required
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <div>
            <label className="block text-sm font-medium text-gray-700">Number of Places:</label>
            <input
              type="number"
              value={places}
              onChange={(e) => setPlaces(e.target.value)}
              required
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Details:</label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          ></textarea>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Plan:</label>
          {plan.map((item, index) => (
            <div key={index} className="flex space-x-2 mt-2">
              <input
                type="date"
                name="date"
                value={item.date}
                onChange={(e) => handlePlanChange(index, e)}
                required
                className="block w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              <input
                type="time"
                name="time"
                value={item.time}
                onChange={(e) => handlePlanChange(index, e)}
                required
                className="block w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              <button
                type="button"
                onClick={() => removePlanField(index)}
                className="bg-red-500 text-white px-4 py-2 rounded-md shadow-sm focus:outline-none"
              >
                Remove
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={addPlanField}
            className="mt-2 bg-blue-500 text-white px-4 py-2 rounded-md shadow-sm focus:outline-none"
          >
            Add Plan
          </button>
        </div>
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          {id ? 'Update Course' : 'Add Course'}
        </button>
      </form>
    </div>
  );
};

export default CourseForm;
