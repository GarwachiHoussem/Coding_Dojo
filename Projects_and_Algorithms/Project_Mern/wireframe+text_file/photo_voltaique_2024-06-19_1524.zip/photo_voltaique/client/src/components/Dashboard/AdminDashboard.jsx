import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Users from './Users';
import MessagesTable from './MessagesTable';
import CoursesTable from './CoursesTable';
import SolarPanelRequestTable from './SolarPanelRequestTable';
import CourseForm from '../CourseForm';
import MyCourses from './Mycourses';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

function AdminDashboard() {
  const {token}=useAuth();
  const navigate =useNavigate();
  const [courses,setCourses]=useState([])
  const [content, setContent] = useState(0); // Assuming content will be dynamic
  const [showModalAdd, setShowModalAdd] = useState(false);
  
  if(!token) return <Navigate to="/" />;
  const handleView = () => {
    setShowModalAdd(true);
  };

  const closeModal = () => {
    setShowModalAdd(false);
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="bg-gray-800 h-screen w-1/5 fixed left-0 top-0">
        <Sidebar setcontent={setContent} />
      </div>

      <div className="flex flex-col w-4/5 ml-auto">
        <div className="p-4">
          {content === 0 && <Users />}
          {content === 1 && (
            <div className="text-center">
              <MessagesTable />
              {/* Profile content here */}
            </div>
          )}
          {content === 2 && (
            <div className="text-center">
              <div className="flex justify-around">
                All Courses
                <button
                  onClick={handleView}
                  className="text-white bg-green-500 block px-3 py-2 rounded-md text-base font-medium"
                >
                  Add Course
                </button>
              </div>
              <CoursesTable courses={courses} setCourses={setCourses} />
              {/* Services content here */}
            </div>
          )}
          {content === 3 && (
            <div className="text-center">
              <h1>Panel Installation Requests</h1>
              <SolarPanelRequestTable />
              {/* Messages content here */}
            </div>
          )}
          {content === 4 && <div className="text-center"><MyCourses/></div>}
          {showModalAdd && (
            <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10" onClick={closeModal}>
              <div className="bg-white p-6 rounded-md shadow-md w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
                <CourseForm closeModal={closeModal} courses={courses} setCourses={setCourses} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
